# Errata

You can see a list of errors that have been found in [_Effective Python_](http://www.effectivepython.com) by looking at the `Confirmed` label for open issues [following this link](https://github.com/bslatkin/effectivepython/issues?q=is%3Aopen+is%3Aissue+label%3AConfirmed). If you found a mistake and don't see it listed there, [please create a new issue](https://github.com/bslatkin/effectivepython/issues/new). Thanks for your help!
