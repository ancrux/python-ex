#!/bin/bash

git clone https://github.com/bslatkin/effectivepython.git

